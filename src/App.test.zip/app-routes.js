import { withNavigationWatcher } from './contexts/navigation';

import {
  HomePage, TasksPage, UsersPage, ClientsPage, ProfilePage, AnalyticsPage,
  EventsPage, AppointmentsPage, FollowupsPage, MedicationRefillsPage, PatientsPage, FacilitiesPage, ResourcesPage,
  CountriesPage, ColorsPage, ColorPage, DiscussionsPage
} from './pages';

const routes = [
  {
    path: '/users',
    component: UsersPage
  },
  {
    path: '/peer-navigators',
    component: ClientsPage
  },
  {
    path: '/participants',
    component: PatientsPage
  },
  {
    path: '/analytics',
    component: AnalyticsPage
  },
  {
    path: '/follow-ups',
    component: FollowupsPage
  },
  {
    path: '/profile',
    component: ProfilePage
  },
  {
    path: '/facilities',
    component: FacilitiesPage
  },
  {
    path: '/resources',
    component: ResourcesPage
  },
  {
    path: '/countries',
    component: CountriesPage
  },
  {
    path: '/colors',
    component: ColorsPage
  },
  {
    path: '/discussions',
    component: DiscussionsPage
  },
  {
    path: '/home',
    component: HomePage
  },
  {
    path: '/color/edit/:eid',
    component: ColorPage
  },
  {
    path: '/color/add',
    component: ColorPage
  }
];

export default routes.map(route => {
  return {
    ...route,
    component: withNavigationWatcher(route.component)
  };
});
