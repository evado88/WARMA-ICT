const AppInfo = {
  appName: 'Twyshe Control Panel',
  apiUrl: 'http://127.0.0.1:5000/',
  onlineApiUrl: 'https://nkoleevans.pythonanywhere.com/',
  localApiUrl: 'http://127.0.0.1:5000/',
  statusList: ['Active', 'Disabled']
};

export default AppInfo;